package jp.co.acroquest.gihyo.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.acroquest.gihyo.demo.entity.Dept;
import jp.co.acroquest.gihyo.demo.entity.Emp;

import org.seasar.extension.jdbc.JdbcManager;
import org.seasar.framework.container.SingletonS2Container;
import org.seasar.framework.container.factory.SingletonS2ContainerFactory;

public class ProblemService {
	private static Map<String, Entity> cache = new HashMap<String, Entity>();

	public JdbcManager jdbcManager;

	public void insert(Entity entity) {
		cache.put(entity.getId(), entity);
	}

	public Map<Dept, List<Emp>> find() {
		Map<Dept, List<Emp>> result = new HashMap<Dept, List<Emp>>();

		List<Dept> list = jdbcManager.from(Dept.class).getResultList();
		for (Dept dept : list) {
			List<Emp> empList = jdbcManager.from(Emp.class)
					.where("dept_id=?", dept.deptNo).getResultList();
			result.put(dept, empList);
		}

		return result;
	}

	public void initContainer() {
		SingletonS2ContainerFactory.init();
		JdbcManager jdbcManager = SingletonS2Container
				.getComponent(JdbcManager.class);
		// jdbcManagerを使ったDBアクセス処理（割愛）
	}
}
