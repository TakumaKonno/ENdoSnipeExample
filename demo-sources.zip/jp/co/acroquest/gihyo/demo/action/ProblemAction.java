package jp.co.acroquest.gihyo.demo.action;

import java.util.Random;

import jp.co.acroquest.gihyo.demo.service.Entity;
import jp.co.acroquest.gihyo.demo.service.ProblemService;

import org.seasar.struts.annotation.Execute;

public class ProblemAction {
	public ProblemService problemService;

	@Execute(validator = false)
	public String index() {
		return "success.jsp";
	}

	@Execute(validator = false, urlPattern = "problem1")
	public String problem1() {
		Random random = new Random(System.currentTimeMillis());
		char key = (char) (random.nextInt(26) + 65);
		for (int i = 0; i < 10000; i++) {
			Entity entity = new Entity(key + "-" + i, null);
			problemService.insert(entity);
		}

		return "success.jsp";
	}

	@Execute(validator = false, urlPattern = "problem2")
	public String problem2() {
		problemService.find();
		return "success.jsp";
	}

	@Execute(validator = false, urlPattern = "problem3")
	public String problem3() {
		for (int i = 0; i < 3; i++) {
			problemService.initContainer();
		}
		return "success.jsp";
	}
}
